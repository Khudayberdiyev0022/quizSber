import React, { useReducer } from "react";
import style from "./Question.module.css";
import image from "../../assets/images/6.svg";
import image1 from "../../assets/images/7.svg";
import img from "../../assets/images/Component2.png";
import img2 from "../../assets/images/Component3.png";
import { questions } from "./QuestionList";

const initialState = {
  selected: null,
  clicked: 1,
  q1: false,
  q2: false,
  allScore: 0,
};
const reducer = (state, action) => {
  switch (action.type) {
    case "SELECTED":
      return {
        ...state,
        selected: action.payload,
      };
    case "BACK":
      return {
        ...state,
        selected: initialState.selected,
      };
    case "CLICKED":
      return {
        ...state,
        clicked: state.clicked + action.payload,
        selected: null,
        allScore: state.allScore + Number(state.selected.score),
      };
    default:
      return state;
  }
};

const Question = () => {
  const [state, dispatch] = useReducer(reducer, initialState);

  const questionRender = () => {
    return (
      <div className={style.contentContainer}>
        <h2>
          <br />
          {state.clicked < 8 && state.clicked} <span>ИЗ 7 ШАГОВ</span>{" "}
        </h2>
        <h1>{questions[state.clicked - 1][0].answer}</h1>
        <div className={style.info}>
          <div className={style.questions}>
            {state.selected !== null && (
              <div className={`${style.active} ${style.question}`}>
                <h3>{state.selected?.text}</h3>
              </div>
            )}
            {state.clicked < 8 &&
              state.selected === null &&
              questions[state.clicked - 1].map((question) => {
                if (state.selected?.id === question.id) {
                  return null;
                } else {
                  return (
                    <div
                      key={question.id}
                      className={style.question}
                      onClick={() => {
                        dispatch({ type: "SELECTED", payload: question });
                      }}
                    >
                      <h3>{question.text}</h3>
                    </div>
                  );
                }
              })}
            {state.selected !== null && (
              <div className={style.answers}>
                <h3>{state.selected.subText}</h3>
              </div>
            )}
            {state.selected !== null && (
              <div className={style.buttons}>
                <div
                  className={style.button2}
                  onClick={() => dispatch({ type: "BACK", payload: 1 })}
                >
                  <h2>Назад</h2>
                </div>
                <div
                  className={style.button1}
                  onClick={() => dispatch({ type: "CLICKED", payload: 1 })}
                >
                  <h2>Следующий вопрос</h2>
                </div>
              </div>
            )}
          </div>
          <div
            className={style.image}
            style={{
              backgroundImage: `url(${state.selected ? img2 : img})`,
            }}
          ></div>
        </div>
      </div>
    );
  };

  const resultRender = () => {
    return (
      <div>
        <h1>Results</h1>
        {state.allScore > 0 && (
          <div>
            {state.allScore < 7 && <h1>yomon</h1>}
            {state.allScore < 13 && <h1>norm</h1>}
            {state.allScore <= 21 && <h1>yaxshi</h1>}
          </div>
        )}
        <h1>{state.allScore}</h1>
      </div>
    );
  };

  return (
    <div style={{ backgroundImage: `url(${image})` }} className={style.main}>
      <div className={style.container}>
        <div
          className={style.content}
          style={{ backgroundImage: `url(${image1})` }}
        >
          {state.clicked < 8 ? questionRender() : resultRender()}
        </div>
      </div>
    </div>
  );
};

export default Question;
