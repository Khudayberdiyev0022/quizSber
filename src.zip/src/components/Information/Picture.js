import React from "react";
import image from "../../assets/images/picture.png";
import style from "./Picture.module.css";

const Picture = () => {
  return (
    <div className={style.main}>
      <img src={image} alt="rasm" width="100%" height="100%" />
    </div>
  );
};

export default Picture;
