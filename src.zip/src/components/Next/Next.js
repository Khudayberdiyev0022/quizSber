import React from "react";
import style from "./Next.module.css";

function Next() {
  return (
    <div className={style.main}>
      <div className={style.button}>
        <h2>Показать все</h2>
      </div>
    </div>
  );
}

export default Next;
